package compilador;

import java.io.*;

public class Compilador {

    public static void main(String[] args) throws IOException {
        PilhaDeVerificacao PilhaVer = new PilhaDeVerificacao();
        PalavrasReservadas ComandosSalvos = new PalavrasReservadas();
        Verificador Verifica = new Verificador(PilhaVer, ComandosSalvos);
        Executor Executa = new Executor();
        
        
        
        Verifica.VerificaSintaxe();
        //Executa.ExecutaArquivo(-Arquivo-);
    }
    
}
