package compilador;

public class Executor {
    
    public Executor(){
        
    }
    
    
}
