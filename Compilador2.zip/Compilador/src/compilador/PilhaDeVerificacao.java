package compilador;

import java.util.ArrayList;

public class PilhaDeVerificacao {
    ArrayList<String> Linhas = new ArrayList();
    
    public PilhaDeVerificacao(){
        
    }
    
    public void teste(){
        
    }
    
    public void AddPilha(String linha){
        //ArrayList com linhas do arquivo
    }
    
    public ArrayList <String> getLinhas(){
        return Linhas;
    }
}
