package compilador;

public class PilhaDeVerificacao {
    
    public PilhaDeVerificacao(){
        
    }
    
    public void teste(){
        
    }
}
