package compilador;

public interface Validavel {
    void valida(String linha);
}
