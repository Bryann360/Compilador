package compilador;

import java.util.*;

public class PalavrasReservadas implements Reservado{
    /**ArrayList com as palavras reservadas*/
    

    @Override
    public void Reservando(){
        
    }
    
    
    public ArrayList <String> getcomandos(){
        
    }
}
