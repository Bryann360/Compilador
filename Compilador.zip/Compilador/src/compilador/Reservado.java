package compilador;

public interface Reservado {
    void Reservando();
}
