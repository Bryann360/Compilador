package compilador;

public class Compilador {

    public static void main(String[] args) {
        PilhaDeVerificacao PilhaVer = new PilhaDeVerificacao();
        Verificador Verifica = new Verificador(PilhaVer);
        Executor Executa = new Executor();
        
        
        
        Verifica.VerificaSintaxe(-Arquivo-);
        Executa.ExecutaArquivo(-Arquivo-);
    }
    
}
