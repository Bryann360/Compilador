package compilador;
import java.util.*;

public class Verificador extends PalavrasReservadas implements Validavel{
    PilhaDeVerificacao Pilha;
    public Verificador(PilhaDeVerificacao pilha){
        this.Pilha = pilha;
    }
    
    @Override
    public void valida(String linha){
        
    }
    
    
    
}
